chrome-time-conversion
======================

A chrome extension for real-time (in browser) conversion of timestamp to readable date format.

http://challengepost.com/software/chrome-time-conversion/
