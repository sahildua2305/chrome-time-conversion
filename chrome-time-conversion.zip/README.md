Timestamp Conversion Chrome Extension
======================

A small chrome extension for real-time simple and easy conversion of timestamp to human readable date format and vice-versa.

## Find it [here](https://chrome.google.com/webstore/detail/timestamp-converter/ndbibeklaoahhlfhdlkddlbnicnhmcad?utm_source=chrome-ntp-icon/)

![](/screenshots/Screenshot%20from%202015-12-25%2020%3A20%3A24.png?raw=true)


## Contact

For any queries or suggestions, feel free to contact us [Sahil Dua](http://www.sahildua.com) and [Prabhakar Gupta](http://www.prabhakargupta.com)
